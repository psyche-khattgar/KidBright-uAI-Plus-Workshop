[basic]
type = cvimodel
model = model.cvimodel

[extra]
model_type = classifier
input_type = rgb
mean = 127.5, 127.5, 127.5
scale = 0.0078125, 0.0078125, 0.0078125
labels = move_backward, turnleft
